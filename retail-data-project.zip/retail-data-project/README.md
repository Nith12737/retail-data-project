# 🛒 Retail Sales — Data Cleaning & Visualization

A beginner-friendly end-to-end data project that simulates a **dirty retail sales dataset**, applies a full **cleaning pipeline**, and produces a **multi-panel visual dashboard**.

---

## 📁 Project Structure

```
retail-data-project/
├── data_generator.py   # Generate synthetic raw (dirty) dataset
├── data_cleaner.py     # Full cleaning pipeline
├── visualizer.py       # Dashboard & all plots
├── main.py             # Run everything end-to-end
├── requirements.txt    # Dependencies
└── README.md
```

---

## 🚀 Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/retail-data-project.git
cd retail-data-project

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the full pipeline
python main.py
```

The dashboard image `sales_dashboard.png` will be saved in the project folder.

---

## 🧹 Cleaning Steps

| Step | Technique |
|------|-----------|
| Duplicate rows | `drop_duplicates()` |
| Negative / impossible values | Replace with `NaN` |
| Outliers | IQR × 2.5 fence |
| Missing values | Category-group median (with global fallback) |
| Feature engineering | Month, quarter extracted from date |
| Revenue | Recalculated after all cleaning |

---

## 📊 Dashboard Panels

- **Monthly Revenue Trend** — line chart with area fill
- **KPI Cards** — total revenue, orders, avg rating, avg order value
- **Revenue by Category** — horizontal bar chart
- **Units Sold by Region** — donut chart
- **Avg Customer Rating** — bar chart
- **Quarterly Revenue by Category** — stacked bar
- **Revenue Distribution** — KDE with mean & median markers

---

## 🛠️ Tech Stack

- `pandas` — data manipulation & cleaning
- `numpy` — numerical operations
- `matplotlib` — plotting & dashboard layout
- `seaborn` — statistical visualizations

---

## 📌 Use Your Own Data

Replace the data generation step in `main.py`:

```python
# Instead of:
raw = generate_raw_data()

# Use your own CSV:
import pandas as pd
raw = pd.read_csv("your_file.csv")
```

---

## 📸 Dashboard Preview

![Dashboard](sales_dashboard.png)

---

## 📄 License

MIT License — free to use and modify.
