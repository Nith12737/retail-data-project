"""
data_cleaner.py
===============
Full cleaning pipeline for the retail sales dataset.

Steps
-----
1. Remove exact duplicate rows
2. Replace impossible (negative) values with NaN
3. Remove outliers using the IQR method
4. Impute missing values (group-median with global fallback)
5. Recalculate derived columns
6. Engineer new features (month, quarter)
"""

import pandas as pd
import numpy as np


# ── Individual cleaning helpers ────────────────────────────────────────────────

def drop_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Remove exact duplicate rows."""
    before = len(df)
    df = df.drop_duplicates()
    print(f"[1] Dropped duplicates   : {before - len(df)} rows removed  →  {len(df)} remain")
    return df


def fix_impossible_values(df: pd.DataFrame) -> pd.DataFrame:
    """Replace negative units_sold with NaN."""
    n = (df["units_sold"] < 0).sum()
    df.loc[df["units_sold"] < 0, "units_sold"] = np.nan
    print(f"[2] Negative units_sold  : {n} values → NaN")
    return df


def remove_outliers_iqr(df: pd.DataFrame,
                         columns: list[str],
                         multiplier: float = 2.5) -> pd.DataFrame:
    """
    Remove rows where any specified column falls outside
    [Q1 - multiplier*IQR, Q3 + multiplier*IQR].
    """
    total_removed = 0
    for col in columns:
        before = len(df)
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lo, hi = Q1 - multiplier * IQR, Q3 + multiplier * IQR
        df = df[(df[col] >= lo) & (df[col] <= hi)].copy()
        removed = before - len(df)
        total_removed += removed
        print(f"[3] Outliers removed ({col:<12}): {removed} rows")
    return df


def impute_missing(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute missing values:
    - Numeric sales columns  → category-group median, then global median fallback
    - customer_age           → global median
    - rating                 → global mean
    """
    # Group-based median with global fallback
    for col in ["units_sold", "unit_price"]:
        group_median = df.groupby("category")[col].transform("median")
        global_median = df[col].median()
        df[col] = df[col].fillna(group_median).fillna(global_median)

    df["customer_age"] = df["customer_age"].fillna(df["customer_age"].median())
    df["rating"]       = df["rating"].fillna(df["rating"].mean())

    print(f"[4] Imputed missing values  →  remaining nulls: {df.isnull().sum().sum()}")
    return df


def recalculate_revenue(df: pd.DataFrame) -> pd.DataFrame:
    """Recompute revenue from clean units_sold × unit_price."""
    df["revenue"] = df["units_sold"] * df["unit_price"]
    print(f"[5] Revenue recalculated")
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add time-based features from the date column."""
    df["month"]      = df["date"].dt.month
    df["month_name"] = df["date"].dt.strftime("%b")
    df["quarter"]    = df["date"].dt.quarter.map(
        {1: "Q1", 2: "Q2", 3: "Q3", 4: "Q4"})
    print(f"[6] Features engineered  : month, month_name, quarter")
    return df


# ── Main pipeline ──────────────────────────────────────────────────────────────

def clean(df: pd.DataFrame,
          iqr_multiplier: float = 2.5) -> pd.DataFrame:
    """
    Run the full cleaning pipeline and return the cleaned DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Raw dataset (output of data_generator.generate_raw_data).
    iqr_multiplier : float
        IQR multiplier for outlier removal. Default 2.5.

    Returns
    -------
    pd.DataFrame
        Cleaned dataset ready for analysis.
    """
    print("=" * 60)
    print("  CLEANING PIPELINE")
    print("=" * 60)

    df = drop_duplicates(df)
    df = fix_impossible_values(df)
    df = remove_outliers_iqr(df, ["units_sold", "unit_price"], iqr_multiplier)
    df = impute_missing(df)
    df = recalculate_revenue(df)
    df = engineer_features(df)

    print()
    print(f"  Final shape  : {df.shape}")
    print(f"  Nulls left   : {df.isnull().sum().sum()}")
    print("=" * 60)
    print()
    return df


if __name__ == "__main__":
    from data_generator import generate_raw_data, print_raw_summary

    raw = generate_raw_data()
    print_raw_summary(raw)
    cleaned = clean(raw)
    print(cleaned.describe())
