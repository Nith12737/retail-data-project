"""
data_generator.py
=================
Generates a synthetic retail sales dataset with intentional
data quality issues (missing values, outliers, duplicates,
negative values) to simulate real-world dirty data.
"""

import numpy as np
import pandas as pd


def generate_raw_data(n_rows: int = 500, seed: int = 42) -> pd.DataFrame:
    """
    Generate a dirty retail sales DataFrame.

    Parameters
    ----------
    n_rows : int
        Base number of orders before duplicates are injected.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        Raw dataset with various data quality problems.
    """
    np.random.seed(seed)

    categories = ["Electronics", "Clothing", "Groceries", "Books", "Furniture"]
    regions    = ["North", "South", "East", "West"]
    date_range = pd.date_range("2023-01-01", "2023-12-31", periods=n_rows)

    df = pd.DataFrame({
        "order_id":     range(1001, 1001 + n_rows),
        "date":         date_range,
        "category":     np.random.choice(categories, n_rows),
        "region":       np.random.choice(regions, n_rows),
        "units_sold":   np.random.randint(1, 50, n_rows).astype(float),
        "unit_price":   np.round(np.random.uniform(5, 500, n_rows), 2),
        "customer_age": np.random.randint(18, 70, n_rows).astype(float),
        "rating":       np.round(np.random.uniform(1, 5, n_rows), 1),
    })
    df["revenue"] = df["units_sold"] * df["unit_price"]

    # ── Inject data quality issues ─────────────────────────────────────────────

    # 1. Missing values
    for col, pct in [("units_sold", 0.06), ("unit_price", 0.04),
                     ("customer_age", 0.08), ("rating", 0.05)]:
        idx = np.random.choice(n_rows, int(n_rows * pct), replace=False)
        df.loc[idx, col] = np.nan

    # 2. Outliers
    df.loc[np.random.choice(n_rows, 8, replace=False), "units_sold"] = \
        np.random.choice([200, 250, 300], 8)
    df.loc[np.random.choice(n_rows, 5, replace=False), "unit_price"] = \
        np.random.choice([5000, 8000], 5)

    # 3. Duplicate rows
    dup_idx = np.random.choice(n_rows, 20, replace=False)
    df = pd.concat([df, df.iloc[dup_idx]], ignore_index=True)

    # 4. Negative / impossible values
    df.loc[np.random.choice(len(df), 6, replace=False), "units_sold"] = -5

    return df


def print_raw_summary(df: pd.DataFrame) -> None:
    """Print a summary of data quality issues in the raw dataset."""
    print("=" * 60)
    print("  RAW DATASET SUMMARY")
    print("=" * 60)
    print(f"  Shape            : {df.shape}")
    print(f"  Duplicates       : {df.duplicated().sum()}")
    missing = df.isnull().sum()
    print(f"  Missing values   :\n{missing[missing > 0]}")
    print(f"  Negative units   : {(df['units_sold'] < 0).sum()}")
    print()


if __name__ == "__main__":
    raw = generate_raw_data()
    print_raw_summary(raw)
    print(raw.head())
