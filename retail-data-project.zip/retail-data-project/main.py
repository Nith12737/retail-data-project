"""
main.py
=======
Entry point — runs the full pipeline end-to-end:
  1. Generate raw (dirty) dataset
  2. Clean the data
  3. Build and save the dashboard
"""

from data_generator import generate_raw_data, print_raw_summary
from data_cleaner   import clean
from visualizer     import build_dashboard


def main():
    print("\n🚀  Retail Sales — Data Cleaning & Visualization\n")

    # Step 1 – Generate
    print("── Step 1: Generating raw dataset ──────────────────────────")
    raw = generate_raw_data(n_rows=500, seed=42)
    print_raw_summary(raw)

    # Step 2 – Clean
    print("── Step 2: Running cleaning pipeline ───────────────────────")
    cleaned = clean(raw, iqr_multiplier=2.5)

    # Step 3 – Visualize
    print("── Step 3: Building dashboard ───────────────────────────────")
    build_dashboard(cleaned, output_path="sales_dashboard.png", dpi=150)

    print("\n🎉  All done!  Open sales_dashboard.png to view the results.\n")


if __name__ == "__main__":
    main()
