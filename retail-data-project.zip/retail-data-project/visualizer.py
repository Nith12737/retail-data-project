"""
visualizer.py
=============
Builds a 7-panel retail sales dashboard and saves it as a PNG.

Panels
------
1. Monthly Revenue Trend      (line + fill)
2. KPI Summary Cards
3. Revenue by Category        (horizontal bar)
4. Units Sold by Region       (donut)
5. Avg Customer Rating        (horizontal bar)
6. Quarterly Revenue          (stacked bar by category)
7. Revenue Distribution       (KDE with mean/median)
"""

import warnings
warnings.filterwarnings("ignore")

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import pandas as pd
import numpy as np


# ── Theme ──────────────────────────────────────────────────────────────────────
PALETTE = ["#4361ee", "#3a0ca3", "#7209b7", "#f72585", "#4cc9f0"]
ACCENT  = "#4361ee"
BG      = "#0f1117"
CARD    = "#1a1d27"
TEXT    = "#e0e0e0"
GRID_C  = "#2a2d3a"

MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _apply_theme() -> None:
    plt.rcParams.update({
        "figure.facecolor": BG,
        "axes.facecolor":   CARD,
        "axes.edgecolor":   GRID_C,
        "axes.labelcolor":  TEXT,
        "xtick.color":      TEXT,
        "ytick.color":      TEXT,
        "text.color":       TEXT,
        "grid.color":       GRID_C,
        "grid.linewidth":   0.6,
        "font.family":      "DejaVu Sans",
    })


def _style_ax(ax, title: str, xlabel: str = "", ylabel: str = "") -> None:
    ax.set_title(title, fontsize=12, fontweight="bold", color=TEXT, pad=8)
    ax.set_xlabel(xlabel, fontsize=9, color=TEXT)
    ax.set_ylabel(ylabel, fontsize=9, color=TEXT)
    ax.grid(True, axis="y", linestyle="--", alpha=0.5)
    ax.tick_params(labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor(GRID_C)


# ── Individual panel builders ──────────────────────────────────────────────────

def _panel_monthly_trend(ax, df: pd.DataFrame) -> None:
    monthly = df.groupby("month")["revenue"].sum().reset_index()
    monthly["label"] = monthly["month"].apply(lambda m: MONTH_LABELS[m - 1])

    ax.plot(monthly["label"], monthly["revenue"] / 1e3,
            color=ACCENT, lw=2.5, marker="o", markersize=6, zorder=3)
    ax.fill_between(monthly["label"], monthly["revenue"] / 1e3,
                    alpha=0.18, color=ACCENT)
    _style_ax(ax, "Monthly Revenue Trend", ylabel="Revenue (K $)")
    ax.set_ylim(bottom=0)


def _panel_kpis(ax, df: pd.DataFrame) -> None:
    ax.axis("off")
    kpis = [
        ("Total Revenue",   f"${df['revenue'].sum() / 1e6:.2f} M"),
        ("Orders",          f"{len(df):,}"),
        ("Avg. Rating",     f"{df['rating'].mean():.2f} ⭐"),
        ("Avg. Order Val.", f"${df['revenue'].mean():.0f}"),
    ]
    for i, (label, val) in enumerate(kpis):
        y = 0.85 - i * 0.22
        ax.text(0.5, y,        val,   ha="center", va="center",
                fontsize=16, fontweight="bold", color="#4cc9f0",
                transform=ax.transAxes)
        ax.text(0.5, y - 0.08, label, ha="center", va="center",
                fontsize=9, color="#aaaaaa", transform=ax.transAxes)
    ax.set_title("Key Metrics", fontsize=12, fontweight="bold",
                 color=TEXT, pad=8)


def _panel_category_revenue(ax, df: pd.DataFrame) -> None:
    cat_rev = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
    bars = ax.barh(cat_rev.index, cat_rev.values / 1e3,
                   color=PALETTE, edgecolor="none", height=0.55)
    for bar in bars:
        w = bar.get_width()
        ax.text(w + 1, bar.get_y() + bar.get_height() / 2,
                f"${w:.0f}K", va="center", fontsize=8, color=TEXT)
    _style_ax(ax, "Revenue by Category", xlabel="Revenue (K $)")
    ax.set_xlim(0, cat_rev.max() / 1e3 * 1.3)
    ax.grid(True, axis="x", linestyle="--", alpha=0.5)
    ax.grid(False, axis="y")


def _panel_region_donut(ax, df: pd.DataFrame) -> None:
    region_units = df.groupby("region")["units_sold"].sum()
    wedges, texts, autotexts = ax.pie(
        region_units,
        labels=region_units.index,
        autopct="%1.1f%%",
        startangle=90,
        colors=PALETTE[:4],
        wedgeprops=dict(width=0.55, edgecolor=BG, linewidth=2),
        pctdistance=0.75,
    )
    for t in texts:     t.set_color(TEXT);  t.set_fontsize(9)
    for t in autotexts: t.set_color(BG);    t.set_fontsize(8); t.set_fontweight("bold")
    ax.set_title("Units Sold by Region", fontsize=12,
                 fontweight="bold", color=TEXT, pad=8)


def _panel_rating_by_category(ax, df: pd.DataFrame) -> None:
    cat_rating = df.groupby("category")["rating"].mean().sort_values()
    ax.barh(cat_rating.index, cat_rating.values,
            color=PALETTE[:len(cat_rating)], edgecolor="none", height=0.5)
    ax.axvline(cat_rating.mean(), color="#f72585", lw=1.5,
               linestyle="--", label=f"Mean {cat_rating.mean():.2f}")
    ax.set_xlim(0, 5.5)
    _style_ax(ax, "Avg. Customer Rating", xlabel="Rating (1–5)")
    ax.legend(fontsize=8, framealpha=0.2)


def _panel_quarterly_stacked(ax, df: pd.DataFrame) -> None:
    pivot = df.pivot_table(
        values="revenue", index="quarter", columns="category", aggfunc="sum"
    )
    pivot.plot(kind="bar", stacked=True, ax=ax,
               color=PALETTE, edgecolor="none", width=0.55)
    _style_ax(ax, "Quarterly Revenue by Category",
              xlabel="Quarter", ylabel="Revenue ($)")
    ax.set_xticklabels(pivot.index, rotation=0, fontsize=9)
    ax.legend(title="Category", fontsize=8, title_fontsize=8,
              framealpha=0.25, loc="upper left")


def _panel_revenue_distribution(ax, df: pd.DataFrame) -> None:
    sns.kdeplot(df["revenue"], ax=ax, fill=True,
                color=ACCENT, alpha=0.4, linewidth=2)
    ax.axvline(df["revenue"].mean(), color="#f72585", lw=1.5,
               linestyle="--", label=f"Mean ${df['revenue'].mean():,.0f}")
    ax.axvline(df["revenue"].median(), color="#4cc9f0", lw=1.5,
               linestyle=":", label=f"Median ${df['revenue'].median():,.0f}")
    _style_ax(ax, "Revenue Distribution", xlabel="Revenue ($)")
    ax.legend(fontsize=8, framealpha=0.2)


# ── Main entry point ───────────────────────────────────────────────────────────

def build_dashboard(df: pd.DataFrame,
                    output_path: str = "sales_dashboard.png",
                    dpi: int = 150) -> None:
    """
    Build and save the full 7-panel dashboard.

    Parameters
    ----------
    df          : Cleaned DataFrame (output of data_cleaner.clean).
    output_path : File path for the saved PNG.
    dpi         : Image resolution.
    """
    _apply_theme()

    fig = plt.figure(figsize=(20, 16), facecolor=BG)
    fig.suptitle("Retail Sales · Annual Dashboard  2023",
                 fontsize=22, fontweight="bold", color=TEXT, y=0.97)

    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.42, wspace=0.32)

    _panel_monthly_trend(fig.add_subplot(gs[0, :2]), df)
    _panel_kpis(fig.add_subplot(gs[0, 2]), df)
    _panel_category_revenue(fig.add_subplot(gs[1, 0]), df)
    _panel_region_donut(fig.add_subplot(gs[1, 1]), df)
    _panel_rating_by_category(fig.add_subplot(gs[1, 2]), df)
    _panel_quarterly_stacked(fig.add_subplot(gs[2, :2]), df)
    _panel_revenue_distribution(fig.add_subplot(gs[2, 2]), df)

    fig.text(
        0.5, 0.005,
        f"Dataset: {len(df):,} cleaned orders  •  "
        "Pipeline: duplicates removed, outliers capped (IQR ×2.5), missing values imputed",
        ha="center", fontsize=8, color="#666688",
    )

    plt.savefig(output_path, dpi=dpi, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"✅  Dashboard saved → {output_path}")


if __name__ == "__main__":
    from data_generator import generate_raw_data
    from data_cleaner import clean

    raw     = generate_raw_data()
    cleaned = clean(raw)
    build_dashboard(cleaned)
